export type Role = "resident" | "prof" | "admin";
export type CaseType =
  | "HOMOLOGATION"
  | "AES"
  | "AT"
  | "VISITE_EMBAUCHE"
  | "AUTRE"
  | "CERT_REPRISE"
  | "CERT_MOYENNE_DUREE"
  | "CERT_LONGUE_DUREE";

export type CaseStatus = "draft" | "submitted" | "validated";
