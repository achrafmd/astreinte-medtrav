import { z } from "zod";
import type { CaseType } from "./types";

export const caseTypeLabels: Record<string, string> = {
  HOMOLOGATION: "Homologation",
  AES: "AES",
  AT: "AT",
  VISITE_EMBAUCHE: "Visite d’embauche",
  AUTRE: "Autre",
  CERT_REPRISE: "Certificat de reprise",
  CERT_MOYENNE_DUREE: "Certificat moyenne durée",
  CERT_LONGUE_DUREE: "Certificat longue durée"
};

const common = {
  date: z.string().min(1, "Date obligatoire"),
  nom: z.string().min(1, "Nom obligatoire"),
  prenom: z.string().min(1, "Prénom obligatoire"),
  age: z.string().optional(),
  fonction: z.string().optional(),
  service: z.string().optional(),
  etablissement: z.string().optional()
};

export const caseSchemas: Record<CaseType, z.ZodTypeAny> = {
  HOMOLOGATION: z.object({ ...common,
    antecedents_pathologiques: z.string().optional(),
    antecedents_professionnels: z.string().optional(),
    motif: z.string().optional(),
    specialite: z.string().optional(),
    nombre_de_jours: z.string().optional(),
    contre_avis: z.string().optional(),
    decision: z.string().optional(),
    nombre_de_jours_homologues: z.string().optional(),
    par_ordre_de: z.string().optional(),
    medecin_astreinte: z.string().optional(),
    observation: z.string().optional()
  }),
  AES: z.object({ ...common,
    poste: z.string().optional(),
    date_heure_accident: z.string().optional(),
    lieu: z.string().optional(),
    objet: z.string().optional(),
    geste: z.string().optional(),
    protection: z.string().optional(),
    vaccination_hvb: z.string().optional(),
    serologie_ps: z.string().optional(),
    soins: z.string().optional(),
    declaration: z.string().optional(),
    prophylaxie: z.string().optional(),
    surveillance_serologie: z.string().optional(),
    suivi: z.string().optional(),
    par_ordre_de: z.string().optional(),
    medecin_astreinte: z.string().optional(),
    numero_telephone: z.string().optional()
  }),
  AT: z.object({ ...common,
    antecedents_pathologiques: z.string().optional(),
    antecedents_professionnels: z.string().optional(),
    motif: z.string().optional(),
    medecin_astreinte: z.string().optional()
  }),
  VISITE_EMBAUCHE: z.object({ ...common,
    antecedents_pathologiques: z.string().optional(),
    antecedents_professionnels: z.string().optional(),
    motif: z.string().optional(),
    par_ordre_de: z.string().optional(),
    medecin_astreinte: z.string().optional(),
    decision: z.string().optional()
  }),
  AUTRE: z.object({ ...common,
    antecedents_pathologiques: z.string().optional(),
    motif: z.string().optional(),
    decision: z.string().optional(),
    medecin: z.string().optional(),
    par_ordre_de: z.string().optional()
  }),
  CERT_REPRISE: z.object({ ...common,
    antecedents_pathologiques: z.string().optional(),
    antecedents_professionnels: z.string().optional(),
    motif: z.string().optional(),
    decision: z.string().optional(),
    par_ordre_de: z.string().optional(),
    medecin_astreinte: z.string().optional()
  }),
  CERT_MOYENNE_DUREE: z.object({ ...common,
    antecedents_pathologiques: z.string().optional(),
    antecedents_professionnels: z.string().optional(),
    motif: z.string().optional(),
    nombre_de_jours: z.string().optional(),
    decision: z.string().optional(),
    nombre_de_jours_homologues: z.string().optional(),
    par_ordre_de: z.string().optional(),
    medecin_astreinte: z.string().optional()
  }),
  CERT_LONGUE_DUREE: z.object({ ...common,
    antecedents_pathologiques: z.string().optional(),
    antecedents_professionnels: z.string().optional(),
    motif: z.string().optional(),
    nombre_de_jours: z.string().optional(),
    decision: z.string().optional(),
    nombre_de_jours_homologues: z.string().optional(),
    par_ordre_de: z.string().optional(),
    medecin_astreinte: z.string().optional()
  })
};

export const fieldsByType: Record<CaseType, { key: string; label: string; textarea?: boolean }[]> = {
  HOMOLOGATION: [
    { key: "date", label: "Date" }, { key: "nom", label: "Nom" }, { key: "prenom", label: "Prénom" },
    { key: "age", label: "Âge" }, { key: "fonction", label: "Fonction" },
    { key: "antecedents_pathologiques", label: "Antécédents pathologiques", textarea: true },
    { key: "antecedents_professionnels", label: "Antécédents professionnels", textarea: true },
    { key: "motif", label: "Motif", textarea: true },
    { key: "specialite", label: "Spécialité" },
    { key: "nombre_de_jours", label: "Nombre de jours" },
    { key: "contre_avis", label: "Contre-avis", textarea: true },
    { key: "decision", label: "Décision", textarea: true },
    { key: "nombre_de_jours_homologues", label: "Nombre de jours homologués" },
    { key: "par_ordre_de", label: "Par ordre de" },
    { key: "medecin_astreinte", label: "Médecin d'astreinte" },
    { key: "observation", label: "Observation", textarea: true }
  ],
  AES: [
    { key: "date", label: "Date" }, { key: "nom", label: "Nom" }, { key: "prenom", label: "Prénom" },
    { key: "age", label: "Âge" }, { key: "poste", label: "Poste" }, { key: "fonction", label: "Fonction" },
    { key: "date_heure_accident", label: "Date et heure de l'accident" },
    { key: "lieu", label: "Lieu" }, { key: "objet", label: "Objet" },
    { key: "geste", label: "Geste", textarea: true },
    { key: "protection", label: "Protection" },
    { key: "vaccination_hvb", label: "Vaccination HVB" },
    { key: "serologie_ps", label: "Sérologie du PS" },
    { key: "soins", label: "Soins", textarea: true },
    { key: "declaration", label: "Déclaration" },
    { key: "prophylaxie", label: "Prophylaxie" },
    { key: "surveillance_serologie", label: "Surveillance / Sérologie", textarea: true },
    { key: "suivi", label: "Suivi", textarea: true },
    { key: "par_ordre_de", label: "Par ordre de" },
    { key: "medecin_astreinte", label: "Médecin d'astreinte" },
    { key: "numero_telephone", label: "Numéro de téléphone" }
  ],
  AT: [
    { key: "date", label: "Date" }, { key: "nom", label: "Nom" }, { key: "prenom", label: "Prénom" },
    { key: "age", label: "Âge" }, { key: "fonction", label: "Fonction" },
    { key: "antecedents_pathologiques", label: "Antécédents pathologiques", textarea: true },
    { key: "antecedents_professionnels", label: "Antécédents professionnels", textarea: true },
    { key: "motif", label: "Motif", textarea: true },
    { key: "medecin_astreinte", label: "Médecin d'astreinte" }
  ],
  VISITE_EMBAUCHE: [
    { key: "date", label: "Date" }, { key: "nom", label: "Nom" }, { key: "prenom", label: "Prénom" },
    { key: "age", label: "Âge" }, { key: "fonction", label: "Fonction" },
    { key: "antecedents_pathologiques", label: "Antécédents pathologiques", textarea: true },
    { key: "antecedents_professionnels", label: "Antécédents professionnels", textarea: true },
    { key: "motif", label: "Motif", textarea: true },
    { key: "par_ordre_de", label: "Par ordre de" },
    { key: "medecin_astreinte", label: "Médecin d'astreinte" },
    { key: "decision", label: "Décision", textarea: true }
  ],
  AUTRE: [
    { key: "date", label: "Date" }, { key: "nom", label: "Nom" }, { key: "prenom", label: "Prénom" },
    { key: "age", label: "Âge" }, { key: "fonction", label: "Fonction" },
    { key: "antecedents_pathologiques", label: "Antécédents pathologiques", textarea: true },
    { key: "motif", label: "Motif", textarea: true },
    { key: "decision", label: "Décision", textarea: true },
    { key: "medecin", label: "Médecin" },
    { key: "par_ordre_de", label: "Par ordre de" }
  ],
  CERT_REPRISE: [
    { key: "date", label: "Date" }, { key: "nom", label: "Nom" }, { key: "prenom", label: "Prénom" },
    { key: "age", label: "Âge" }, { key: "fonction", label: "Fonction" },
    { key: "antecedents_pathologiques", label: "Antécédents pathologiques", textarea: true },
    { key: "antecedents_professionnels", label: "Antécédents professionnels", textarea: true },
    { key: "motif", label: "Motif", textarea: true },
    { key: "decision", label: "Décision", textarea: true },
    { key: "par_ordre_de", label: "Par ordre de" },
    { key: "medecin_astreinte", label: "Médecin d'astreinte" }
  ],
  CERT_MOYENNE_DUREE: [
    { key: "date", label: "Date" }, { key: "nom", label: "Nom" }, { key: "prenom", label: "Prénom" },
    { key: "age", label: "Âge" }, { key: "fonction", label: "Fonction" },
    { key: "antecedents_pathologiques", label: "Antécédents pathologiques", textarea: true },
    { key: "antecedents_professionnels", label: "Antécédents professionnels", textarea: true },
    { key: "motif", label: "Motif", textarea: true },
    { key: "nombre_de_jours", label: "Nombre de jours" },
    { key: "decision", label: "Décision", textarea: true },
    { key: "nombre_de_jours_homologues", label: "Nombre de jours homologués" },
    { key: "par_ordre_de", label: "Par ordre de" },
    { key: "medecin_astreinte", label: "Médecin d'astreinte" }
  ],
  CERT_LONGUE_DUREE: [
    { key: "date", label: "Date" }, { key: "nom", label: "Nom" }, { key: "prenom", label: "Prénom" },
    { key: "age", label: "Âge" }, { key: "fonction", label: "Fonction" },
    { key: "antecedents_pathologiques", label: "Antécédents pathologiques", textarea: true },
    { key: "antecedents_professionnels", label: "Antécédents professionnels", textarea: true },
    { key: "motif", label: "Motif", textarea: true },
    { key: "nombre_de_jours", label: "Nombre de jours" },
    { key: "decision", label: "Décision", textarea: true },
    { key: "nombre_de_jours_homologues", label: "Nombre de jours homologués" },
    { key: "par_ordre_de", label: "Par ordre de" },
    { key: "medecin_astreinte", label: "Médecin d'astreinte" }
  ]
};
