import { supabaseBrowser } from "./supabaseBrowser";

export type Facility = { id: string; name: string };
export type Department = { id: string; facility_id: string; name: string };

export async function fetchFacilities() {
  const supabase = supabaseBrowser();
  const { data, error } = await supabase.from("facilities").select("id,name").order("name");
  if (error) throw error;
  return (data ?? []) as Facility[];
}

export async function fetchDepartments(facilityId: string) {
  const supabase = supabaseBrowser();
  const { data, error } = await supabase
    .from("departments")
    .select("id,facility_id,name")
    .eq("facility_id", facilityId)
    .order("name");
  if (error) throw error;
  return (data ?? []) as Department[];
}
