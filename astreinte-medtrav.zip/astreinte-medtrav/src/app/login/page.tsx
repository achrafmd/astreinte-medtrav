"use client";
import { useState } from "react";
import { supabaseBrowser } from "@/lib/supabaseBrowser";

export default function LoginPage() {
  const supabase = supabaseBrowser();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [msg, setMsg] = useState<string | null>(null);

  async function signIn(e: React.FormEvent) {
    e.preventDefault();
    setMsg(null);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) return setMsg(error.message);
    window.location.href = "/dashboard";
  }

  return (
    <main className="rounded-2xl bg-white p-6 shadow">
      <h1 className="text-xl font-semibold">Connexion</h1>
      <form className="mt-4 grid gap-3" onSubmit={signIn}>
        <label className="grid gap-1">
          <span className="text-sm text-gray-700">Email</span>
          <input className="rounded-xl border px-3 py-2" value={email} onChange={(e)=>setEmail(e.target.value)} />
        </label>
        <label className="grid gap-1">
          <span className="text-sm text-gray-700">Mot de passe</span>
          <input type="password" className="rounded-xl border px-3 py-2" value={password} onChange={(e)=>setPassword(e.target.value)} />
        </label>
        <button className="rounded-xl bg-black px-4 py-2 text-white">Se connecter</button>
        {msg && <div className="text-sm text-red-600">{msg}</div>}
      </form>
      <p className="mt-4 text-sm text-gray-600">
        Les comptes se créent dans Supabase (Authentication). Les rôles se gèrent dans la table <b>profiles</b>.
      </p>
    </main>
  );
}
