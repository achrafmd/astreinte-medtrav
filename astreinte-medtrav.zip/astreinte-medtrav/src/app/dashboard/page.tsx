"use client";
import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { supabaseBrowser } from "@/lib/supabaseBrowser";
import type { CaseStatus, CaseType } from "@/lib/types";
import { caseTypeLabels } from "@/lib/forms";

type CaseRow = {
  id: string; type: CaseType; status: CaseStatus; date: string;
  nom: string; prenom: string; service: string | null; etablissement: string | null; created_at: string;
};

export default function Dashboard() {
  const supabase = supabaseBrowser();
  const [rows, setRows] = useState<CaseRow[]>([]);
  const [type, setType] = useState<string>("ALL");
  const [status, setStatus] = useState<string>("ALL");
  const [q, setQ] = useState("");

  async function load() {
    const { data: session } = await supabase.auth.getSession();
    if (!session.session) return (window.location.href = "/login");

    let query = supabase
      .from("cases")
      .select("id,type,status,date,nom,prenom,service,etablissement,created_at")
      .order("created_at", { ascending: false })
      .limit(300);

    if (type !== "ALL") query = query.eq("type", type);
    if (status !== "ALL") query = query.eq("status", status);

    const { data, error } = await query;
    if (error) return alert(error.message);
    setRows((data ?? []) as any);
  }

  useEffect(() => { load(); }, [type, status]);

  const filtered = useMemo(() => {
    const qq = q.trim().toLowerCase();
    if (!qq) return rows;
    return rows.filter(r =>
      [r.nom, r.prenom, r.service ?? "", r.etablissement ?? "", r.date ?? ""].join(" ").toLowerCase().includes(qq)
    );
  }, [rows, q]);

  return (
    <main className="rounded-2xl bg-white p-6 shadow">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-xl font-semibold">Dashboard</h1>
        <div className="flex gap-2">
          <Link className="rounded-xl bg-black px-4 py-2 text-white" href="/cases/new">Nouveau dossier</Link>
          <button className="rounded-xl border px-4 py-2" onClick={async () => { await supabase.auth.signOut(); window.location.href="/login"; }}>
            Déconnexion
          </button>
        </div>
      </div>

      <div className="mt-4 grid gap-3 md:grid-cols-3">
        <input className="rounded-xl border px-3 py-2" placeholder="Recherche (nom, prénom, service, établissement, date…)" value={q} onChange={(e)=>setQ(e.target.value)} />
        <select className="rounded-xl border px-3 py-2" value={type} onChange={(e)=>setType(e.target.value)}>
          <option value="ALL">Tous les types</option>
          {Object.entries(caseTypeLabels).map(([k,v]) => <option key={k} value={k}>{v}</option>)}
        </select>
        <select className="rounded-xl border px-3 py-2" value={status} onChange={(e)=>setStatus(e.target.value)}>
          <option value="ALL">Tous les statuts</option>
          <option value="draft">Brouillon</option>
          <option value="submitted">Soumis</option>
          <option value="validated">Validé</option>
        </select>
      </div>

      <div className="mt-6 overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="text-left text-gray-600">
            <tr>
              <th className="py-2">Date</th><th>Type</th><th>Nom</th><th>Prénom</th><th>Établissement</th><th>Service</th><th>Statut</th><th></th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((r) => (
              <tr key={r.id} className="border-t">
                <td className="py-2">{r.date}</td>
                <td>{caseTypeLabels[r.type]}</td>
                <td>{r.nom}</td>
                <td>{r.prenom}</td>
                <td>{r.etablissement ?? ""}</td>
                <td>{r.service ?? ""}</td>
                <td>{r.status}</td>
                <td className="text-right"><Link className="underline" href={`/cases/${r.id}`}>Ouvrir</Link></td>
              </tr>
            ))}
            {filtered.length === 0 && <tr><td className="py-6 text-gray-500" colSpan={8}>Aucun dossier</td></tr>}
          </tbody>
        </table>
      </div>
    </main>
  );
}
