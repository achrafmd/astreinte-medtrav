"use client";
import { useEffect, useMemo, useState } from "react";
import { supabaseBrowser } from "@/lib/supabaseBrowser";
import type { CaseType } from "@/lib/types";
import { caseTypeLabels, caseSchemas, fieldsByType } from "@/lib/forms";
import { fetchDepartments, fetchFacilities, type Department, type Facility } from "@/lib/reference";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";

export default function NewCasePage() {
  const supabase = supabaseBrowser();
  const [type, setType] = useState<CaseType>("HOMOLOGATION");
  const [facilities, setFacilities] = useState<Facility[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [facilityId, setFacilityId] = useState<string>("");

  const schema = useMemo(() => caseSchemas[type], [type]);
  const form = useForm<any>({
    resolver: zodResolver(schema),
    defaultValues: { date: new Date().toISOString().slice(0, 10) }
  });

  useEffect(() => { (async () => setFacilities(await fetchFacilities()))().catch(console.error); }, []);

  async function onSelectFacility(id: string) {
    setFacilityId(id);
    const fac = facilities.find((f) => f.id === id);
    form.setValue("etablissement", fac?.name ?? "");
    form.setValue("service", "");
    setDepartments(await fetchDepartments(id));
  }

  async function save(values: any, submit: boolean) {
    const { data: session } = await supabase.auth.getSession();
    if (!session.session) return (window.location.href = "/login");

    const payload = {
      type,
      status: submit ? "submitted" : "draft",
      date: values.date,
      nom: values.nom,
      prenom: values.prenom,
      service: values.service ?? null,
      etablissement: values.etablissement ?? null,
      data: values
    };

    const { data, error } = await supabase.from("cases").insert(payload).select("id").single();
    if (error) return alert(error.message);
    window.location.href = `/cases/${data.id}`;
  }

  const fields = fieldsByType[type];

  return (
    <main className="rounded-2xl bg-white p-6 shadow">
      <h1 className="text-xl font-semibold">Nouveau dossier</h1>

      <div className="mt-4">
        <label className="grid gap-1">
          <span className="text-sm text-gray-700">Type</span>
          <select
            className="rounded-xl border px-3 py-2"
            value={type}
            onChange={(e) => {
              setType(e.target.value as CaseType);
              form.reset({ date: new Date().toISOString().slice(0, 10) });
              setFacilityId(""); setDepartments([]);
            }}
          >
            {Object.entries(caseTypeLabels).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
        </label>
      </div>

      <div className="mt-4 grid gap-3 md:grid-cols-2">
        <label className="grid gap-1">
          <span className="text-sm text-gray-700">Établissement</span>
          <select className="rounded-xl border px-3 py-2" value={facilityId} onChange={(e) => onSelectFacility(e.target.value)}>
            <option value="">— Sélectionner —</option>
            {facilities.map((f) => <option key={f.id} value={f.id}>{f.name}</option>)}
          </select>
        </label>

        <label className="grid gap-1">
          <span className="text-sm text-gray-700">Service</span>
          <select
            className="rounded-xl border px-3 py-2"
            value={(form.watch("service") as string) ?? ""}
            onChange={(e) => form.setValue("service", e.target.value)}
            disabled={!facilityId}
          >
            <option value="">— Sélectionner —</option>
            {departments.map((d) => <option key={d.id} value={d.name}>{d.name}</option>)}
          </select>
        </label>
      </div>

      <form className="mt-4 grid gap-3" onSubmit={form.handleSubmit((v) => save(v, true))}>
        {fields.map((f) => (
          <label key={f.key} className="grid gap-1">
            <span className="text-sm text-gray-700">{f.label}</span>
            {f.textarea
              ? <textarea className="min-h-[90px] rounded-xl border px-3 py-2" {...form.register(f.key)} />
              : <input className="rounded-xl border px-3 py-2" {...form.register(f.key)} />
            }
          </label>
        ))}

        <div className="mt-2 flex flex-wrap gap-2">
          <button type="button" className="rounded-xl border px-4 py-2" onClick={form.handleSubmit((v) => save(v, false))}>
            Enregistrer brouillon
          </button>
          <button className="rounded-xl bg-black px-4 py-2 text-white">Soumettre</button>
        </div>
      </form>
    </main>
  );
}
