"use client";
import { useEffect, useMemo, useState } from "react";
import { useParams } from "next/navigation";
import { supabaseBrowser } from "@/lib/supabaseBrowser";
import type { CaseType, CaseStatus } from "@/lib/types";
import { caseTypeLabels, caseSchemas, fieldsByType } from "@/lib/forms";
import { fetchDepartments, fetchFacilities, type Department, type Facility } from "@/lib/reference";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";

type CaseRecord = {
  id: string;
  type: CaseType;
  status: CaseStatus;
  data: any;
  created_by: string;
  validated_by: string | null;
  validated_at: string | null;
};

export default function CasePage() {
  const { id } = useParams<{ id: string }>();
  const supabase = supabaseBrowser();
  const [rec, setRec] = useState<CaseRecord | null>(null);
  const [role, setRole] = useState<"resident" | "prof" | "admin" | null>(null);
  const [uid, setUid] = useState<string | null>(null);

  const [facilities, setFacilities] = useState<Facility[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [facilityId, setFacilityId] = useState<string>("");

  useEffect(() => {
    (async () => {
      const { data: session } = await supabase.auth.getSession();
      if (!session.session) return (window.location.href = "/login");
      setUid(session.session.user.id);

      const prof = await supabase.from("profiles").select("role").eq("id", session.session.user.id).single();
      setRole((prof.data?.role ?? "resident") as any);

      const { data, error } = await supabase.from("cases").select("*").eq("id", id).single();
      if (error) return alert(error.message);
      setRec(data as any);

      const facs = await fetchFacilities();
      setFacilities(facs);

      const etabName = (data as any)?.data?.etablissement ?? "";
      const fac = facs.find((f) => f.name === etabName);
      if (fac) {
        setFacilityId(fac.id);
        setDepartments(await fetchDepartments(fac.id));
      }
    })().catch(console.error);
  }, [id]);

  const type = rec?.type ?? "HOMOLOGATION";
  const schema = useMemo(() => caseSchemas[type], [type]);
  const form = useForm<any>({ resolver: zodResolver(schema), values: rec?.data ?? {} });

  const canEdit =
    rec && uid &&
    (rec.status === "draft" || role === "prof" || role === "admin") &&
    (rec.created_by === uid || role !== "resident");

  const canValidate = rec && (role === "prof" || role === "admin") && rec.status !== "validated";

  async function onSelectFacility(fid: string) {
    setFacilityId(fid);
    const fac = facilities.find((f) => f.id === fid);
    form.setValue("etablissement", fac?.name ?? "");
    form.setValue("service", "");
    setDepartments(await fetchDepartments(fid));
  }

  async function update(values: any) {
    if (!rec) return;
    const { error } = await supabase.from("cases").update({
      data: values,
      date: values.date,
      nom: values.nom,
      prenom: values.prenom,
      service: values.service ?? null,
      etablissement: values.etablissement ?? null
    }).eq("id", rec.id);

    if (error) return alert(error.message);
    alert("Mis à jour");
  }

  async function setStatus(s: CaseStatus) {
    if (!rec) return;
    const { error } = await supabase.from("cases").update({ status: s }).eq("id", rec.id);
    if (error) return alert(error.message);
    window.location.reload();
  }

  async function validateNow() {
    if (!rec) return;
    const { error } = await supabase.from("cases").update({
      status: "validated",
      validated_by: uid,
      validated_at: new Date().toISOString()
    }).eq("id", rec.id);
    if (error) return alert(error.message);
    window.location.reload();
  }

  if (!rec) return <main className="rounded-2xl bg-white p-6 shadow">Chargement…</main>;

  const fields = fieldsByType[type];

  return (
    <main className="rounded-2xl bg-white p-6 shadow">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold">
            {caseTypeLabels[rec.type]} — {rec.data?.nom} {rec.data?.prenom}
          </h1>
          <div className="text-sm text-gray-600">Statut: <b>{rec.status}</b></div>
        </div>
        <div className="flex flex-wrap gap-2">
          {rec.status === "draft" && (
            <button className="rounded-xl border px-4 py-2" onClick={() => setStatus("submitted")}>
              Soumettre
            </button>
          )}
          {canValidate && (
            <button className="rounded-xl bg-black px-4 py-2 text-white" onClick={validateNow}>
              Valider
            </button>
          )}
        </div>
      </div>

      <div className="mt-4 grid gap-3 md:grid-cols-2">
        <label className="grid gap-1">
          <span className="text-sm text-gray-700">Établissement</span>
          <select className="rounded-xl border px-3 py-2 disabled:bg-gray-100" value={facilityId} onChange={(e) => onSelectFacility(e.target.value)} disabled={!canEdit}>
            <option value="">— Sélectionner —</option>
            {facilities.map((f) => <option key={f.id} value={f.id}>{f.name}</option>)}
          </select>
        </label>

        <label className="grid gap-1">
          <span className="text-sm text-gray-700">Service</span>
          <select className="rounded-xl border px-3 py-2 disabled:bg-gray-100" value={(form.watch("service") as string) ?? ""} onChange={(e) => form.setValue("service", e.target.value)} disabled={!canEdit || !facilityId}>
            <option value="">— Sélectionner —</option>
            {departments.map((d) => <option key={d.id} value={d.name}>{d.name}</option>)}
          </select>
        </label>
      </div>

      <form className="mt-4 grid gap-3" onSubmit={form.handleSubmit(update)}>
        {fields.map((f) => (
          <label key={f.key} className="grid gap-1">
            <span className="text-sm text-gray-700">{f.label}</span>
            {f.textarea
              ? <textarea className="min-h-[90px] rounded-xl border px-3 py-2 disabled:bg-gray-100" disabled={!canEdit} {...form.register(f.key)} />
              : <input className="rounded-xl border px-3 py-2 disabled:bg-gray-100" disabled={!canEdit} {...form.register(f.key)} />
            }
          </label>
        ))}
        {canEdit && <button className="mt-2 rounded-xl border px-4 py-2">Enregistrer</button>}
        {!canEdit && <div className="mt-2 text-sm text-gray-600">Lecture seule (dossier validé ou droits insuffisants).</div>}
      </form>
    </main>
  );
}
